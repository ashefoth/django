from django.shortcuts import render

from app.models import news, users

def main_file(request):
    News1 = news.objects.all()
    site = 'app/News.html'
    abc = users.objects.get(id = 1)
    context={
    'News1': News1,
    'a': abc
    }
    


    return render(request, site, context)
                      
