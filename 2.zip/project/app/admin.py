from django.contrib import admin
from app import models
from app.models import news
from app.models import users
from app.models import comment

class NewsAdmin(admin.ModelAdmin):
    list_display = ('tittle', 'text', 'date', 'author',  'category')
admin.site.register(news, NewsAdmin)

class usersAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'email', 'role')
admin.site.register(users, usersAdmin)

class commentAdmin(admin.ModelAdmin):
    list_display = ('news_id', 'user_id', 'comment_text')
admin.site.register(comment, commentAdmin)

