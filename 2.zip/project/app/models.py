from django.db import models

class news(models.Model):
    tittle = models.CharField(u'заголовок', max_length = 64)
    text = models.CharField(u'текст_поста', max_length = 1000)
    date = models.DateTimeField(auto_now_add=True)
    author = models.CharField(u'автор', max_length = 64)
    category = models.CharField(u'категория', max_length = 50)
    def __str__(self):
        return str(self.id)

class users(models.Model):
    first_name = models.CharField(u'имя', max_length = 12)
    last_name = models.CharField(u'фамилия', max_length = 15)
    email = models.CharField(u'электронная_почта', max_length = 35)
    role = models.CharField(u'роль', max_length = 10)
    def __str__(self):
        return str(self.id)
    

class comment(models.Model):
    news_id=models.ForeignKey(news, on_delete=models.CASCADE, default = 0)
    user_id=models.ForeignKey(users, on_delete=models.CASCADE, default = 0)
    comment_text = models.CharField(u'Текст_коммента', max_length = 300, default = 0)
    def __str__(self):
        return str(self.id)