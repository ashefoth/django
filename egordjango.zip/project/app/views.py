from django.shortcuts import render

from app.models import news

def main_file(request):
    News1 = news.objects.all()
    site = 'app/News.html'
    context={
    'News1': News1
    }
    

    return render(request, site, context)
                      
